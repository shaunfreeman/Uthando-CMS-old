/*
---

script: Form.Validator.Catalan.js

description: Date messages for Catalan.

license: MIT-style license

authors:
- Miquel Hudin
- Alfons Sanchez

requires:
- /Lang
- /Form.Validator

provides: [Form.Validator.Catalan]

...
*/

MooTools.lang.set('ca-CA', 'Form.Validator', {

	required:'Aquest camp es obligatori.',
	minLength:'Per favor introdueix al menys {minLength} caracters (has introduit {length} caracters).',
	maxLength:'Per favor introdueix no mes de {maxLength} caracters (has introduit {length} caracters).',
	integer:'Per favor introdueix un nombre enter en aquest camp. Nombres amb decimals (p.e. 1,25) no estan permesos.',
	numeric:'Per favor introdueix sols valors numerics en aquest camp (p.e. "1" o "1,1" o "-1" o "-1,1").',
	digits:'Per favor usa sols numeros i puntuacio en aquest camp (per exemple, un nombre de telefon amb guions i punts no esta permes).',
	alpha:'Per favor utilitza lletres nomes (a-z) en aquest camp. No s´admiteixen espais ni altres caracters.',
	alphanum:'Per favor, utilitza nomes lletres (a-z) o numeros (0-9) en aquest camp. No s´admiteixen espais ni altres caracters.',
	dateSuchAs:'Per favor introdueix una data valida com {date}',
	dateInFormatMDY:'Per favor introdueix una data valida com DD/MM/YYYY (p.e. "31/12/1999")',
	email:'Per favor, introdueix una adreça de correu electronic valida. Per exemple,  "fred@domain.com".',
	url:'Per favor introdueix una URL valida com http://www.google.com.',
	currencyDollar:'Per favor introdueix una quantitat valida de €. Per exemple €100,00 .',
	oneRequired:'Per favor introdueix alguna cosa per al menys una d´aquestes entrades.',
	errorPrefix: 'Error: ',
	warningPrefix: 'Avis: ',

	//Form.Validator.Extras

	noSpace: 'No poden haver espais en aquesta entrada.',
	reqChkByNode: 'No hi han elements seleccionats.',
	requiredChk: 'Aquest camp es obligatori.',
	reqChkByName: 'Per favor selecciona una {label}.',
	match: 'Aquest camp necessita coincidir amb el camp {matchName}',
	startDate: 'la data de inici',
	endDate: 'la data de fi',
	currendDate: 'la data actual',
	afterDate: 'La data deu ser igual o posterior a {label}.',
	beforeDate: 'La data deu ser igual o anterior a {label}.',
	startMonth: 'Per favor selecciona un mes d´orige',
	sameMonth: 'Aquestes dos dates deuen estar dins del mateix mes - deus canviar una o altra.'

});