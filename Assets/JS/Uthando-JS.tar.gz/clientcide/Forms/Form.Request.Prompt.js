/*
Script: Form.Request.Prompt.js
	Prompts the user with the contents of a form (retrieved via ajax) and updates a DOM element with the result of the submission.

License:
	http://www.clientcide.com/wiki/cnet-libraries#license
*/
(function(){
	
	var prompter = function(ext){
		return {
			Extends: ext,
			options: {
				//onUpdate: $empty,
				stickyWinToUse: StickyWin.Modal,
				stickyWinOptions: {},
				caption: 'Update Info',
				useUi: true,
				stickyWinUiOptions: {
					width: 500
				},
				useSpinner: true
			},
			initialize: function(form, update, options){
				this.setOptions(options);
				this.update = document.id(update);
				this.makeStickyWin(form);
				this.swin.addEvent('close', function(){
					if (this.request && this.request.spinner) this.request.spinner.hide();
				});
				this.addEvent('success', this.hide.bind(this));
			},
			makeStickyWin: function(form){
				if (document.id(form)) form = document.id(form);
				this.swin = new this.options.stickyWinToUse({
					content: this.options.useUi?StickyWin.ui(this.options.caption, form, this.options.stickyWinUiOptions):form,
					showNow: false
				});
				this.element = this.swin.win.getElement('form');
				this.initAfterUpdate();
			},
			hide: function(){
				this.swin.hide();
				return this;
			},
			prompt: function(){
				this.swin.show();
				return this;
			},
			initAfterUpdate: function(){
				this.setOptions({
					requestOptions: {
						useSpinner: this.options.useWaiter || this.options.useSpinner,
						spinnerTarget: document.id(this),
						spinnerOptions: {
							layer: {
								styles: {
									zIndex: 10001
								}
							}
						}
					}
				});
				this.makeRequest();
				this.attach();
				document.id(this).store('form.request', this);
			}
		};
	};
	
	Form.Request.Prompt = new Class(prompter(Form.Request));
	if (Form.Request.Append) Form.Request.Append.Prompt = new Class(prompter(Form.Request.Append));
	
	
	var ajaxPrompter = function(ext) {
		return {
			Extends: ext,
			options: {
				stickyWinToUse: StickyWin.Modal.Ajax
			},
			makeStickyWin: function(formUrl){
				if (this.swin) return this.swin;
				this.swin = new this.options.stickyWinToUse($merge({
					showNow: false,
					requestOptions: this.options.requestOptions,
					onHide: function(){
						this.win.empty();
					},
					url: formUrl,
					handleResponse: function(response) {
						var responseScript = "";
						this.swin.Request.response.text.stripScripts(function(script){	responseScript += script; });
						var content = this.options.useUi?StickyWin.ui(this.options.caption, response, this.options.stickyWinUiOptions):response;
						this.swin.setContent(content);
						if (this.options.requestOptions.evalScripts) $exec(responseScript);
						this.element = this.swin.win.getElement('form');
						this.initAfterUpdate();
						this.swin.show();
					}.bind(this)
				}, this.options.stickyWinOptions));
				return this.swin;
			},
			prompt: function(){
				this.makeStickyWin().update();
				return this;
			}
		};
	};

	Form.Request.AjaxPrompt = new Class(ajaxPrompter(Form.Request.Prompt));
	if (Form.Request.Append) Form.Request.Append.AjaxPrompt = new Class(ajaxPrompter(Form.Request.Append.Prompt));
})();