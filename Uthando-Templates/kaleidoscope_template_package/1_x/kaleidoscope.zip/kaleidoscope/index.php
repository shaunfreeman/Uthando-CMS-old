<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$iso = split( '=', _ISO );
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php if ( $my->id ) initEditor(); ?>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<?php mosShowHead(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo $mosConfig_live_site;?>/templates/kaleidoscope/css/style.css"/>
</head>
<body>
	<div class="header"> 
		<div class="right_header">
   			<p>&nbsp;</p>
    		<?php mosLoadModules('user4'); ?>
    	</div>
	
    	<div class="logo">
      		<h1><?php echo $mosConfig_sitename; ?></h1>
		</div>
    	
		
		<div id="mainlevel-nav">
    		<?php mosLoadModules ( 'user3' ); ?>
    	</div>
	</div>  
   
<table width="100%" cellpadding="0" cellspacing="0" style="clear: both;">

     
<tr>
    <?php if(mosCountModules('left') + mosCountModules('user2') > 0) { ?>
    <td width="200" valign="top">
    <?php } else { ?>
    <td>
    <?php } ?>
    
        <table width="196" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td>
                <?php mosLoadModules('left'); ?>
            </td>
        </tr>
        </table>
        
       
    </td>
    <td valign="top">

        <br>
        
        <table width="98%" cellpadding="0" cellspacing="0" align="center" style="line-height:140%;">
        <tr>
                   
            <td>
              <?php mosLoadModules('user6'); ?>
            </td>
        </tr>
        </table>
                    
        
        <table width="98%" cellpadding="0" cellspacing="0" align="center" style="line-height: 1.5em;">
        <tr>
            <td>
                 <?php mosMainBody(); ?>
            </td>
        </tr>
        </table>

      
        
        <table width="98%" cellpadding="0" cellspacing="0" align="center">
        <tr>
            <td>
                 <?php mosLoadModules('bottom'); ?>
            </td>
        </tr>
        </table>
    </td>
    
    <?php if(mosCountModules('right') + mosCountModules('user1') > 0) { ?>
    <td valign="top" width="200">
    <?php } else { ?>
    <td>
    <?php } ?>
    
        <table width="98%" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td>
                <?php mosLoadModules('right'); ?>
            </td>
        </tr>
        </table>
        
        <table width="98%" align="center" cellpadding="0" cellspacing="0" style="margin-top: 20px; padding: 0;">
        <tr>
            <td>
                <?php mosLoadModules('user1'); ?>
            </td>
        </tr>
        </table>
        
    </td>
</tr>

</table>
<div class="footer">
<p><?php include_once('includes/footer.php'); ?></p>
</div>
</body>
</html>