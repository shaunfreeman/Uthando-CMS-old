<?php defined( "_VALID_MOS" ) or die( "Direct Access to this location is not allowed." );$iso = split( '=', _ISO );?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php mosShowHead(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php if ( $my->id ) { initEditor(); } ?>
<?php echo "<link rel=\"stylesheet\" href=\"$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/template_css.css\" type=\"text/css\"/>" ; ?>
<?php echo "<link rel=\"stylesheet\" href=\"$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/layout_css.css\" type=\"text/css\"/>" ; ?>
<?php echo "<link rel=\"shortcut icon\" href=\"$GLOBALS[mosConfig_live_site]/templates/blogger_blue/favicon.ico\" />" ; ?>
<link rel="alternate" title="<?php echo $mosConfig_sitename; ?>" href="<?php echo $GLOBALS['mosConfig_live_site']; ?>/index2.php?option=com_rss&no_html=1" type="application/rss+xml" />
<script language="JavaScript" type="text/javascript">
    <!--
    function MM_reloadPage(init) {  //reloads the window if Nav4 resized
      if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
        document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
      else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
    }
    MM_reloadPage(true);
    //-->
  </script>
<style type="text/css">
<!--
.Stil1 {
	font-size: xx-small;
	color: #FFFFFF;
}
body {
	background-image: url();
	background-attachment:fixed;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #EEEEEE;
}
-->
</style>
</head>

<body>

<div id="main">
 <div id="s_top"><!--  --></div>
 		 <div id="content">
		 			<div id="top">
							 <h1><?php echo $mosConfig_sitename; ?></h1>
							 <div id="searchform">
							   			<?php mosLoadModules ('user4');?>			
							 </div>	
					</div>
					<div id="menu"><div id="uls"><?php mosLoadModules ('user3'); ?></div></div>
		 			<div id="cols">
							 <div id="col_left">
							 			<?php mosLoadModules('left'); ?>
							 </div>
							 <div id="col_right">
							 			<?php mosMainBody(); ?>
							 </div>
							 
					</div>
					<div class="both"><!--  --></div>
					
					<div id="footer">
					<p>Copyright � 2007 Add Your Company Footer Text Here<br />
  					Joomla Templates By
  					<a href="http://www.joomladesigns.co.uk/">JoomlaDesigns</a></p>								
					</div>
		 
		 </div>
 <div id="s_bottom"><!--  --></div>
</div>
<div class="both"><!--  --></div>
</body>
</html>
