﻿<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head"  style="xhtml" />
<link rel="stylesheet" href="templates/_system/css/general.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template_css.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/layout_css.css" type="text/css" />

<link rel="alternate" title="<?php echo $mainframe->getCfg('sitename');?>" href="index2.php?option=com_rss&amp;no_html=1" type="application/rss+xml" />
<script language="JavaScript" type="text/javascript">
    <!--
    function MM_reloadPage(init) {  //reloads the window if Nav4 resized
      if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
        document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
      else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
    }
    MM_reloadPage(true);
    //-->
  </script>
<style type="text/css">
<!--
.Stil1 {
	font-size: xx-small;
	color: #FFFFFF;
}
body {
	background-image: url();
	background-attachment:fixed;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #EEEEEE;
}
-->
</style>
<link rel="shortcut icon" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/favicon.ico" />
</head>
<body>
<div id="main">
  <div id="s_top">
    <!--  -->
  </div>
  <div id="content">
    <div id="top">
      <h1><?php echo $mainframe->getCfg('sitename');?></h1>
      <div id="searchform">
        <jdoc:include type="modules" name="user4" />
      </div>
    </div>
    <div id="menu">
      <div id="uls">
        <jdoc:include type="modules" name="user3" style="xhtml" />
        <div class="both">
          <!--  -->
        </div>
      </div>
    </div>
    <div id="cols">
      <div id="col_left">
        <jdoc:include type="modules" name="left" style="xhtml" />
      </div>
      <div id="col_right">
        <jdoc:include type="component" style="xhtml" />
      </div>
    </div>
    <div class="both">
      <!--  -->
    </div>
    <div id="footer">
      <p>Copyright 2007 Add Your Company Footer Text Here<br />
        Joomla Templates By <a href="http://www.joomladesigns.co.uk/">JoomlaDesigns</a></p>
    </div>
  </div>
  <div id="s_bottom">
    <!--  -->
  </div>
</div>
<div class="both">
  <!--  -->
</div>
</body>
</html>
