<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
  defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' ); ?>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link href="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->    getTemplate(); ?>/css/template_css.css" rel="stylesheet" type="text/css" media="all"/>
		<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/md_stylechanger.js"></script>
    <link rel="shortcut icon" href="<?php echo $mosConfig_live_site;?>/images/favicon.ico" />
<?php 
if ( $my->id ) { initEditor(); }
mosShowHead(); 
?>
<style type="text/css">
/*<![CDATA[*/
<?php
    if (isset($_COOKIE['fontSize']) && $_COOKIE['fontSize']!='100')
    {
        echo '    body { font-size: '.$_COOKIE['fontSize'].'%;}'."\n";
    }
    else
    {
        echo '    body { font-size: 100%;}'."\n";
    }
?>
/*]]>*/
</style>
</head>
<body>
<div id="content">
		 <div id="line_top"><img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/images/cl.gif" id="cl" alt="-" /></div>
		 <div id="left_col">
		 			<div id="top_logo">
							 <h1><?php echo $mosConfig_sitename; ?><span> Corp.</span></h1>
							 <img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/images/logo.gif" id="logo" alt="<?php echo $mosConfig_sitename; ?> Corp." title="<?php echo $mosConfig_sitename; ?> Corp." />
					</div>
					<div class="mod_user1"> <?php mosLoadModules ('user5', -2);?> </div>
					<div class="mod_user2"> <?php mosLoadModules ('user6', -2);?> </div>
					<div class="mod_user3"> <?php mosLoadModules ('user7', -2);?> </div>					 
		 </div>
		 <div id="right_col">
		 			<?php mosLoadModules('left', -2); ?>
					<?php mosLoadModules('right', -2);?>
					<?php mosLoadModules('user1', -2);?>
		 </div>
		 <div id="main_content">
		 			<div class="padding">
    		 			<div id="right_top">
    							 <div id="right_top_left">
    							 			<h2><span>Business corp.</span><br />slogan here</h2>
    							 			<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium... <br/><a href="#">READ MORE ABOUT US ...</a></p>
    							 			<img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/images/globe.jpg" id="globe" alt="" />
												<a href="index.php" title="Increase size" onclick="changeFontSize(2);return false;" id="plus"><img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/images/larger.gif" alt="Increase size" title="Increase size" border="0" /></a>
												<a href="index.php" title="Decrease size" onclick="changeFontSize(-2);return false;" id="minus"><img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/images/smaller.gif" alt="Decrease size" title="Decrease size" border="0" /></a>
												<a href="index.php" title="Revert styles to default" onclick="revertStyles(); return false;" id="revert"><img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/images/reset.gif" alt="Revert styles to default" title="Revert styles to default" border="0" /></a>												
    							 </div>
    							 <div class="both"><!--  --></div>
    					</div>		 			
							 <?php  if(mosCountModules('top')) { ?>
							 <div id="newsflash"><?php mosLoadModules ('top', -2);?></div>
							 <?php } ?>
							 <?php mosMainBody(); ?>
					</div>
					
		 </div>
		 <div class="both"><!--  --></div>
</div>
<div id="footer">
								 			<p>Copyright &copy; Your Footer Text 
											Goes Here 2006-2007<br />
											<a href="http://www.joomladesigns.co.uk/">
											Joomla Templates By JoomlaDesigns.co.uk</a></p>
								 </div>	<?php mosLoadModules( 'debug', -1 );?>	
</body>
</html>

