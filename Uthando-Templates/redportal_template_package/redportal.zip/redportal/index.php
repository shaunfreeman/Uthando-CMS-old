<?php defined( "_VALID_MOS" ) or die( "Direct Access to this location is not allowed." );$iso = split( '=', _ISO );?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php mosShowHead(); ?>
<?php if ( $my->id ) { initEditor(); } ?>
<?php echo "<link rel=\"stylesheet\" href=\"$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/template_css.css\" type=\"text/css\"/>" ; ?>
		<?php echo "<link rel=\"stylesheet\" href=\"$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/layout_css.css\" type=\"text/css\"/>" ; ?>
		<link rel="shortcut icon" href="<?php echo $mosConfig_live_site;?>/images/favicon.ico" />
		<?php include($mosConfig_absolute_path."/templates/$GLOBALS[cur_template]/menu.php"); ?>
<script language="JavaScript" type="text/javascript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body>
<div id="content">	
		  <div id="menu"><div id="uls"><?php mosLoadModules ('user3'); ?></div></div>
			<div id="nfo_line">
					 <span>You are here: </span><?php mosPathWay(); ?>
			 		 <?php if(mosCountModules('top')) { ?><div id="searchform">
		 			 <?php mosLoadModules ('user4');?>			
		 			 </div><?php } ?>		
			</div>
      <div id="top">
					 <img src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe-> getTemplate(); ?>/images/logo.gif" alt="logo" id="logo" />				 			 				 
  				 <h1><?php echo $mosConfig_sitename; ?></h1>	
					 <?php if(mosCountModules('top')) { ?>
					 <div id="newsflash">
        				<div class="newsflash"><?php mosLoadModules ('top');?></div>
					 </div><?php } ?>
			</div>
			<div id="silver_line"><!--  --></div>
  		<div id="main">	
						<div id="right_side">
      				<div id="mosright">
      					<div class="padding">
      						<?php mosLoadModules('right'); 
      							  if(mosCountModules('user1') && $Itemid!='2')  mosLoadModules('user1'); ?>	
      					</div>
      				</div>
      				<?php if(mosCountModules('right')) { ?>
      							<div id="mcontent"><div class="padding"><?php mosMainBody(); ?></div></div>
      				<?php } else { ?>
      							<div id="mcontent2"><div class="padding"><?php mosMainBody(); ?></div></div>
      				<?php } ?>
      			</div>
      			<div id="left_side">
      				<div class="lefts">
      					<?php mosLoadModules('left'); ?>	
      				</div>
      			</div><div class="both"><!-- --></div>
      </div>
 		<div id="footer">
			<div class="padding">
				<p>Copyright � 2007 Add Your Company Footer Text Here<br />
  					Joomla Templates By
  					<a href="http://www.joomladesigns.co.uk/">JoomlaDesigns</a></p>
			</div>	
 		</div>
</div>
</body>
</html>
