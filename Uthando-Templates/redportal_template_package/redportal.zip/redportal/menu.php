<?php
$mymenu_content = <<<EOT
<table border="0" cellspacing="0" cellpadding="0">
	  <tr>

EOT;
	global $database, $my;
		$Itemid = mosgetParam( $_REQUEST, 'Itemid', 0 );
		$database->setQuery( "SELECT m.* FROM #__menu AS m"
	. "\nWHERE menutype='topmenu' AND published=1 AND access <= $my->gid"
	. "\nORDER BY sublevel,ordering"
	);
		$rows = $database->loadObjectList( 'id' );
	echo $database->getErrorMsg();
	$current_itemid = $Itemid;
	if ($current_itemid == 0) {
		$current_itemid ="1";
	}
	$mytabs = count($rows);	
	
	$tabcounter = 0;
		foreach ($rows as $row) { // insert top-menu items
			if ($row->parent == 0 && (trim( $row->link ))) {
				$name = addslashes( $row->name );
				$alt = addslashes( $row->name );
				$link = $row->link ? "$row->link" : "null";
				if ($row->type != "url") {
					$link .= "&Itemid=$row->id";
				}
				// Custom mod to replace the \' that the code creates with only a '
				
				$name = str_replace("\'","'",$name);
				
				$link = sefRelToAbs($link);
				if ($tabcounter == 0) {
					if ( $current_itemid == $row->id) {
						$mymenu_content .= "<td><a href=\"$link\" class=\"mainmenu\" id=\"active\">$name</a></td>";
						$closetab = true;
					} else {
							$mymenu_content .= "<td><a href=\"$link\" class=\"mainmenu\">$name</a></td>";
					}					
				} else {
					if ( $current_itemid == $row->id) {
						$mymenu_content .= "<td><a href=\"$link\" class=\"mainmenu\" id=\"active\">$name</a></td>";
						$closetab = true;
					} else {
						if ($closetab == true) {
							$closetab = false;
							}else{
			$mymenu_content .= "<td >|</td>";
						}
						$mymenu_content .= "<td><a href=\"$link\" class=\"mainmenu\">$name</a></td>";
					}
				}
			$tabcounter++;
			}
		}

		if ($closetab == true) {
			$mymenu_content .= "<td >|</td>";
		} else {
			$mymenu_content .= "";
		}

$mymenu_content .= <<<EOT
  </tr>
</table>
EOT;
?>